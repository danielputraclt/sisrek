<template>
  <v-row>
      <v-col>
          <Form />
      </v-col>
      <v-col>
          <Table />
      </v-col>
  </v-row>
</template>

<script>
export default {

}
</script>

<style>

</style>