export default {
    buildModules: [
        "@nuxtjs/vuetify"
    ],
    modules: [
        "@nuxtjs/axios"
    ],
    components: true
}