# MEVN Stack FullStack Application


- [x] Node 
- [x] Express 
- [x] Mongoose
- [x] Babel
- [x] Nuxt
- [x] Vuetify
- [x] Aios
- [x] Cors
- [x] dotenv  

`Serverside code`

```
cd apis
yarn 
yarn start
```
`Clientside code`
```
cd app
yarn 
yarn start
```